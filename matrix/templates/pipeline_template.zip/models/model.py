

# You can write your torch, tensorflow, sklearn or other models here
# you can also use custom scripts
# these scripts usually will be used inside pipeline.py, load_model function